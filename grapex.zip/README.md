# GrapeX 🍇

Grape leaf disease detection app with backend + mobile frontend.
